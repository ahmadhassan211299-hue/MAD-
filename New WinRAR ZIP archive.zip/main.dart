import 'package:flutter/material.dart';
import 'dashboard.dart';

void main() {
  runApp(const HemavisionApp());
}

class HemavisionApp extends StatelessWidget {
  const HemavisionApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Hemavision - Blood Cancer Detection',
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: const Dashboard(),
    );
  }
}